





document.getElementById("closeVerticalSection1_1").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_1_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_1_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_1_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_1_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_1_4").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_2_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_2_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_2_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_2_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_2_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_2_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_2_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_2_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection1_2_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection1_2_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection1_2_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection1_2_4").src="icons/close.png";
};



document.getElementById("closeVerticalSection2_1").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_1").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_1").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_1").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_1_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_1_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_1_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_1_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_1_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_1_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_1_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_1_4").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_2_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_2_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_2_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_2_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_2_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_2_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_2_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_2_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection2_2_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection2_2_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection2_2_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection2_2_4").src="icons/close.png";
};



document.getElementById("closeVerticalSection3_1").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_1").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_1").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_1").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_1_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_1_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_1_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_1_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_1_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_1_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_1_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_1_4").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_2_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_2_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_2_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_2_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_2_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_2_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_2_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_2_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection3_2_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection3_2_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection3_2_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection3_2_4").src="icons/close.png";
};



document.getElementById("closeVerticalSection4_1").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_1").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_1").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_1").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_1_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_1_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_1_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_1_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_1_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_1_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_1_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_1_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_1_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_1_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_1_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_1_4").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_2_2").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_2_2").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_2_2").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_2_2").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_2_3").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_2_3").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_2_3").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_2_3").src="icons/close.png";
};

document.getElementById("closeVerticalSection4_2_4").onmouseover = function() { 
    document.getElementById("closeVerticalSection4_2_4").src="icons/closeHover.png";
};
document.getElementById("closeVerticalSection4_2_4").onmouseout = function() { 
    document.getElementById("closeVerticalSection4_2_4").src="icons/close.png";
};



document.getElementById("DoorLeft_S1").onmouseover = function() { 
    document.getElementById("DoorLeft_S1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S1").onmouseout = function() {
    document.getElementById("DoorLeft_S1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S1").onmouseover = function() { 
    document.getElementById("DoorRight_S1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S1").onmouseout = function() {
    document.getElementById("DoorRight_S1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S1").onmouseout = function() {
    document.getElementById("DoubleDoor_S1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S1").onmouseover = function() { 
    document.getElementById("Drawer_S1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S1").onmouseout = function() {
    document.getElementById("Drawer_S1").src="icons/Drawer_Close.jpg";
};



document.getElementById("DoorLeft_S2").onmouseover = function() { 
    document.getElementById("DoorLeft_S2").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S2").onmouseout = function() {
    document.getElementById("DoorLeft_S2").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S2").onmouseover = function() { 
    document.getElementById("DoorRight_S2").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S2").onmouseout = function() {
    document.getElementById("DoorRight_S2").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S2").onmouseover = function() { 
    document.getElementById("DoubleDoor_S2").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S2").onmouseout = function() {
    document.getElementById("DoubleDoor_S2").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S2").onmouseover = function() { 
    document.getElementById("Drawer_S2").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S2").onmouseout = function() {
    document.getElementById("Drawer_S2").src="icons/Drawer_Close.jpg";
};



document.getElementById("DoorLeft_S3_1").onmouseover = function() { 
    document.getElementById("DoorLeft_S3_1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S3_1").onmouseout = function() {
    document.getElementById("DoorLeft_S3_1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S3_1").onmouseover = function() { 
    document.getElementById("DoorRight_S3_1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S3_1").onmouseout = function() {
    document.getElementById("DoorRight_S3_1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S3_1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S3_1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S3_1").onmouseout = function() {
    document.getElementById("DoubleDoor_S3_1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S3_1").onmouseover = function() { 
    document.getElementById("Drawer_S3_1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S3_1").onmouseout = function() {
    document.getElementById("Drawer_S3_1").src="icons/Drawer_Close.jpg";
};


document.getElementById("DoorLeft_S4_1").onmouseover = function() { 
    document.getElementById("DoorLeft_S4_1").src="icons/DoorLeft_Open.jpg";
};
document.getElementById("DoorLeft_S4_1").onmouseout = function() {
    document.getElementById("DoorLeft_S4_1").src="icons/DoorLeft_Close.jpg";
};

document.getElementById("DoorRight_S4_1").onmouseover = function() { 
    document.getElementById("DoorRight_S4_1").src="icons/DoorRight_Open.jpg";
};
document.getElementById("DoorRight_S4_1").onmouseout = function() {
    document.getElementById("DoorRight_S4_1").src="icons/DoorRight_Close.jpg";
};

document.getElementById("DoubleDoor_S4_1").onmouseover = function() { 
    document.getElementById("DoubleDoor_S4_1").src="icons/DoubleDoor_Open.jpg";
};
document.getElementById("DoubleDoor_S4_1").onmouseout = function() {
    document.getElementById("DoubleDoor_S4_1").src="icons/DoubleDoor_Close.jpg";
};

document.getElementById("Drawer_S4_1").onmouseover = function() { 
    document.getElementById("Drawer_S4_1").src="icons/Drawer_Open.jpg";
};
document.getElementById("Drawer_S4_1").onmouseout = function() {
    document.getElementById("Drawer_S4_1").src="icons/Drawer_Close.jpg";
};


/* setTimeout(function(){
    PopUpClickWindow.style.display = 'flex';
    PopUpClickWindow.style.animation = 'animationOpacityShow 4s';
},800);

setTimeout(function(){
    PopUpClickWindow.style.animation = 'animationOpacityHide 2s';
},6600);

setTimeout(function(){
    PopUpClickWindow.style.display = 'none';
},7300); */






/* 
function openInternalShelving_S1() {
    var checkBox_HorizontalPartition_S1 = document.getElementById("InternalShelving_S1");

    if (checkBox_HorizontalPartition_S1.checked == true) {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "flex";
        document.getElementById("Drawer_S1").style.pointerEvents = "none";
        document.getElementById("Drawer_Section1").style.pointerEvents = "none";
        document.getElementById("Drawer_S1").src="icons/Drawer_Disable.jpg";
        
    } 
    else {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "none";
    }
} */



/* function openInternalShelving_S1_1_2() {
    var checkBox_HorizontalPartition_S1_1 = document.getElementById("InternalShelving_S1_1_2");

    if (checkBox_HorizontalPartition_S1_1_2.checked == true) {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "flex";
        document.getElementById("Drawer_S1").style.pointerEvents = "none";
        document.getElementById("Drawer_Section1").style.pointerEvents = "none";
        document.getElementById("Drawer_S1").src="icons/Drawer_Disable.jpg";
        
    } 
    else {
        document.getElementById("sectionMoveInternalShelving_S1_1").style.display = "none";
    }
}
 */











const leftArrow = document.querySelector('.arrow-btn.left');
const rightArrow = document.querySelector('.arrow-btn.right');
const dimensionMenu = document.querySelector('.dimensionMenu');
const dimensionNames = document.querySelectorAll('.dimensionName');

// Amount to scroll (width of one dimensionName + its margin)
const scrollAmount = dimensionNames[0].offsetWidth;

// Scroll left
leftArrow.addEventListener('click', function() {
    dimensionMenu.scrollBy({ top: 0, left: -scrollAmount, behavior: 'smooth' });
});

// Scroll right
rightArrow.addEventListener('click', function() {
    dimensionMenu.scrollBy({ top: 0, left: scrollAmount, behavior: 'smooth' });
});

// Change color of arrow buttons when a menu is selected
dimensionNames.forEach(function(name) {
    name.addEventListener('click', function() {
        leftArrow.classList.add('selected');
        rightArrow.classList.add('selected');
    });
});

// main menu mobile version 
const menuMap = {
    "buttonWidth": "menuWidth",
    "buttonDepth": "menuDepth",
    "buttonHeight": "menuHeight",
    "buttonFeet": "menuFeet",
    "buttonVerticalPart": "menuVerticalPart",
    "buttonCarcassColour": "menuCarcassColour",
    "buttonFrontFacadesColour": "menuFrontFacadesColour",
    "buttonBackPanels": "menuBackPanels"
};

var buttons = document.querySelectorAll('.dimensionName');
var submenus = Object.values(menuMap).map(id => document.getElementById(id));


// Attach click event listener to each button
buttons.forEach(function(button) {
    button.addEventListener('click', function(e) {
        // Get the id of the button
        var buttonId = this.id;

        // Reset color and background-color of all buttons
        buttons.forEach(function(btn) {
            btn.style.backgroundColor = "#e9e9ed";
            btn.style.color = "black";
        });

        // Change color and background-color of the clicked button
        this.style.backgroundColor = "#356b4d";
        this.style.color = "white";

        // Get the id of the corresponding submenu from the map
        var submenuId = menuMap[buttonId];

        // Get the submenu element
        var submenu = document.getElementById(submenuId);
        submenus.forEach(sm => sm.style.display = "none");
        submenu.style.display = "flex";

    });
});